class Topping {
  final String name;
  final int price;

  Topping({required this.name, required this.price});
}
